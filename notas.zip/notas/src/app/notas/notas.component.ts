import { CommonModule } from '@angular/common';
import { ChangeDetectionStrategy, Component } from '@angular/core';
import { TableModule } from 'primeng/table'; // Importa el módulo de la tabla de PrimeNG
import { ToolbarModule } from 'primeng/toolbar'; // Importa el módulo de la barra de herramientas de PrimeNG
import { InputTextModule } from 'primeng/inputtext';
import { RippleModule } from 'primeng/ripple';
import { ButtonModule } from 'primeng/button';

@Component({
  selector: 'app-notas',
  standalone: true,
  imports: [
    CommonModule,
    TableModule,
    ToolbarModule,
    InputTextModule,
    RippleModule,
    ButtonModule,
  ],
  templateUrl: './notas.component.html',
  styleUrl: './notas.component.css',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class NotasComponent {
  productDialog: boolean = false;

  submitted: boolean = false;

  statuses!: any[];

  openNew() {
    this.submitted = false;
    this.productDialog = true;
  }

  editProduct() {}

  deleteProduct() {}

  hideDialog() {
    this.productDialog = false;
    this.submitted = false;
  }

  saveProduct() {
    this.submitted = true;
  }

  findIndexById() {}

  createId() {}

  getSeverity() {}
}
