import {
  InputText,
  InputTextModule
} from "./chunk-DFMHK6KB.js";
import "./chunk-CVLI7GHA.js";
import "./chunk-P6BN7I6E.js";
export {
  InputText,
  InputTextModule
};
//# sourceMappingURL=primeng_inputtext.js.map
