import {
  Ripple,
  RippleModule
} from "./chunk-RYKIKBNL.js";
import "./chunk-2QAOXEUH.js";
import "./chunk-CVLI7GHA.js";
import "./chunk-P6BN7I6E.js";
export {
  Ripple,
  RippleModule
};
//# sourceMappingURL=primeng_ripple.js.map
