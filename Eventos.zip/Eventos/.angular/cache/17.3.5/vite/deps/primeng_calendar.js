import {
  CALENDAR_VALUE_ACCESSOR,
  Calendar,
  CalendarModule
} from "./chunk-O6DZY7DV.js";
import "./chunk-RY2Z3R6Z.js";
import "./chunk-4HYDLR6U.js";
import "./chunk-E2DVRNDG.js";
import "./chunk-FW2W7NLJ.js";
import "./chunk-2QAOXEUH.js";
import "./chunk-CVLI7GHA.js";
import "./chunk-P6BN7I6E.js";
export {
  CALENDAR_VALUE_ACCESSOR,
  Calendar,
  CalendarModule
};
//# sourceMappingURL=primeng_calendar.js.map
