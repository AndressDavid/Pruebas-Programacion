import {
  Button,
  ButtonDirective,
  ButtonModule
} from "./chunk-FW2W7NLJ.js";
import "./chunk-2QAOXEUH.js";
import "./chunk-CVLI7GHA.js";
import "./chunk-P6BN7I6E.js";
export {
  Button,
  ButtonDirective,
  ButtonModule
};
//# sourceMappingURL=primeng_button.js.map
