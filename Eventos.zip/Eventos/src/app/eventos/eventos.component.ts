import { Component } from '@angular/core';

@Component({
  selector: 'app-eventos',
  templateUrl: './eventos.component.html',
  styleUrl: './eventos.component.css',
})
export class EventosComponent {
  public searchDate: Date | undefined;
  public isNewEventModalVisible = false;
  public fechaIsValid = true;
  public eventoIsValid = true;
  public newEvent = { fecha: new Date(), evento: '' };
  public selectedEvent: any;
  public isEditEventModalVisible = false;
  public isDeleteEventConfirmVisible = false;
  public currentEvent = { id: 0, fecha: new Date(), evento: '' };
  public events = [
    { id: 1, fecha: new Date('2024-04-18'), evento: 'Evento 1' },
    { id: 2, fecha: new Date('2024-04-19'), evento: 'Evento 2' },
    { id: 3, fecha: new Date('2024-04-20'), evento: 'Evento 3' },
  ];

  search() {
    if (this.searchDate) {
      this.filteredEvents = this.events.filter((event) => {
        // Comparar la fecha del evento con la fecha seleccionada
        const eventDate = new Date(event.fecha);
        return eventDate.toDateString() === this.searchDate!.toDateString();
      });
    } else {
      // Si no se selecciona ninguna fecha, muestra todos los eventos
      this.filteredEvents = [...this.events];
    }
  }

  openNewEventModal() {
    this.isNewEventModalVisible = true;
  }

  public editFechaIsValid = true;
  public editEventoIsValid = true;

  saveEditEvent() {
    // Verifica si los campos de fecha y evento están vacíos
    this.editFechaIsValid = !!this.currentEvent.fecha;
    this.editEventoIsValid = !!this.currentEvent.evento;

    if (!this.editFechaIsValid || !this.editEventoIsValid) {
      return;
    }

    // Lógica para guardar los cambios en el evento
    const index = this.events.findIndex(
      (event) => event.id === this.currentEvent.id
    );
    if (index !== -1) {
      this.events[index] = { ...this.currentEvent };
    }

    if (this.searchDate) {
      this.filteredEvents = this.events.filter((event) => {
        const eventDate = new Date(event.fecha);
        return eventDate.toDateString() === this.searchDate!.toDateString();
      });
    } else {
      this.filteredEvents = [...this.events];
    }

    this.isEditEventModalVisible = false;
  }

  cancelEditEvent() {
    this.isEditEventModalVisible = false;
  }

  handleVisibleChange(event: any) {
    console.log(event);
    this.isDeleteEventConfirmVisible = event;
    if (typeof event === 'boolean') {
      this.isDeleteEventConfirmVisible = event;
    } else {
      console.error('Unexpected event type:', event);
    }
  }

  deleteEvent() {
    // Lógica para eliminar el evento
    const index = this.events.findIndex(
      (event) => event.id === this.currentEvent.id
    );
    if (index !== -1) {
      this.events.splice(index, 1);
    }
    this.filteredEvents = this.events.filter((event) => {
      return true;
    });
    this.isDeleteEventConfirmVisible = false;
  }

  cancelDeleteEvent() {
    this.isDeleteEventConfirmVisible = false;
  }

  editEvent(event: { id: number; fecha: Date; evento: string }) {
    this.currentEvent = { ...event };
    this.isEditEventModalVisible = true;
  }

  confirmDeleteEvent(event: { id: number; fecha: Date; evento: string }) {
    this.currentEvent = event;
    this.isDeleteEventConfirmVisible = true;
  }
  public filteredEvents: any[] = [...this.events];

  saveNewEvent() {
    this.fechaIsValid = !!this.newEvent.fecha;
    this.eventoIsValid = !!this.newEvent.evento;

    if (!this.fechaIsValid || !this.eventoIsValid) {
      return;
    }

    // Añadir el nuevo evento
    const newEvent = { ...this.newEvent, id: this.events.length + 1 };
    this.events.push(newEvent);

    this.filteredEvents.push(newEvent);

    // Cerrar el modal y resetear el nuevo evento
    this.isNewEventModalVisible = false;
    this.newEvent = { fecha: new Date(), evento: '' };
    this.fechaIsValid = true;
    this.eventoIsValid = true;
  }
  cancelNewEvent() {
    this.isNewEventModalVisible = false;
    // Resetear el nuevo evento
    this.newEvent = { fecha: new Date(), evento: '' };
  }
}
