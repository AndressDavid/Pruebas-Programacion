import { NgModule } from '@angular/core';
import {
  BrowserModule,
  provideClientHydration,
} from '@angular/platform-browser';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { CalendarModule } from 'primeng/calendar';
import { FormsModule } from '@angular/forms';
import { DialogModule } from 'primeng/dialog';
import { TableModule } from 'primeng/table';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { ConfirmDialogModule } from 'primeng/confirmdialog';
import { ConfirmationService } from 'primeng/api';
import { EventosComponent } from './eventos/eventos.component';

@NgModule({
  declarations: [AppComponent, EventosComponent],
  imports: [
    BrowserModule,
    AppRoutingModule,
    CalendarModule,
    FormsModule,
    DialogModule,
    TableModule,
    BrowserAnimationsModule,
    ConfirmDialogModule,
  ],
  providers: [provideClientHydration(), ConfirmationService],
  bootstrap: [AppComponent],
})
export class AppModule {}
